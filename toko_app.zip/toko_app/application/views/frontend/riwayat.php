<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>Shop Homepage - Start Bootstrap Template</title>
  <!-- Favicon-->
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
  <!-- Bootstrap icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <!-- Core theme CSS (includes Bootstrap)-->
  <link href="<?= base_url('assets/template/toko/') ?>css/styles.css" rel="stylesheet" />
</head>

<body>
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container px-4 px-lg-5">
      <a class="navbar-brand" href="<?= base_url('homepage/page') ?>">7 Eleven</a>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Store</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <?php foreach ($store as $list) : ?>
                <li><a class="dropdown-item"><?= $list['alamat_store'] ?></a></li>
              <?php endforeach; ?>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Kategori</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="<?= base_url('homepage/page/') ?>">All Products</a></li>
              <li>
                <hr class="dropdown-divider" />
              </li>

              <?php foreach ($kategori as $list) : ?>
                <li><a class="dropdown-item" href="<?= base_url('homepage/page/' . $list['id_kategori']) ?>"><?= $list['nama_kategori'] ?></a></li>
              <?php endforeach; ?>
            </ul>
          </li>

          <?php if ($this->session->userdata('id_customer') == null) { ?>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('login_customer') ?>">Login</a></li>
          <?php } else { ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?= $this->session->userdata('nama_customer') ?></a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="<?= base_url('riwayat') ?>">Riwayat Pembelian</a></li>
                <li><a class="dropdown-item" href="<?= base_url('logout_customer') ?>">Logout</a></li>
              </ul>
            </li>
          <?php }  ?>

        </ul>
        <button class="btn btn-outline-dark" data-toggle="modal" data-target="#cart">
          <i class="bi-cart-fill me-1"></i>
          Cart
          <?php
          $jmlCart = $this->OrderModel->GetJmlCart($this->session->userdata('id_customer'));
          ?>
          <span class="badge bg-dark text-white ms-1 rounded-pill"><?= $jmlCart ?></span>
        </button>
      </div>
    </div>
  </nav>
  <!-- Header-->
  <header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
      <div class="text-center text-white">
        <h1 class="display-4 fw-bolder">7 Eleven</h1>
      </div>
    </div>
  </header>

  <!-- Section-->
  <section class="py-5">

    <div class="container px-4 px-lg-5 mt-2">
      <h3>Riwayat Pembelian</h3>
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga Satuan</th>
            <th>Tanggal</th>
            <th>Status Order</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($riwayat as $list) : ?>
            <tr>
              <td><?= $list['nama_produk'] ?></td>
              <td><?= $list['nama_kategori'] ?></td>
              <td><?= $list['harga'] ?></td>
              <td><?= $list['tgl_order'] ?></td>
              <?php if ($list['status_order'] == 0) { ?>
                <td>Belum Bayar</td>
              <?php } else { ?>
                <td>Sudah Bayar</td>
              <?php } ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- Modal -->
  <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Peringatan</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          Silakan login terlebih dahulu untuk dapat membeli barang !
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a type="button" class="btn btn-primary" href="<?= base_url('login_customer') ?>">Login</a>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Order Cart</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <table>
            <tr>
              <td>Produk</td>
              <td> </td>
              <td>Harga</td>
            </tr>
            <?php
            $total = 0;
            foreach ($cart as $list) : ?>
              <tr>
                <td><?= $list['nama_produk'] ?></td>
                <td> </td>
                <td> Rp. <?= $list['harga'] ?></td>
                <?php
                $total = $total + $list['harga'];
                ?>
              </tr>
            <?php endforeach ?>

          </table>
          <br>
          <p>Total Bayar : Rp. <?= $total ?></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a type="button" class="btn btn-primary" href="<?= base_url('homepage/bayar') ?>">Bayar</a>
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    <?php if ($this->session->flashdata('flash') == 'success') { ?>
      alert("Pembayaran Berhasil Dilakukan !!!");
    <?php } else if ($this->session->flashdata('flash') == 'error') { ?>
      alert("Pembayaran Gagal Dilakukan !!!");
    <?php } ?>
  </script>

  <!-- Footer-->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2021</p>
    </div>
  </footer>
  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/template/toko/') ?>js/scripts.js"></script>
</body>

</html>