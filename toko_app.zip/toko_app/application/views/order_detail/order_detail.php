<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Order</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Produk</th>
              <th>Kategori</th>
              <th>Harga Satuan</th>
              <th>Tanggal</th>
              <th>Status Order</th>
              <th>Customer</th>
              <th style="width: 300px;">Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($order as $list) : ?>
              <tr>
                <td><?= $list['nama_produk'] ?></td>
                <td><?= $list['nama_kategori'] ?></td>
                <td><?= $list['harga'] ?></td>
                <td><?= $list['tgl_order'] ?></td>
                <?php if ($list['status_order'] == 0) { ?>
                  <td>Belum Bayar</td>
                <?php } else { ?>
                  <td>Sudah Bayar</td>
                <?php } ?>

                <td><?= $list['nama_customer'] ?></td>
                <td>
                  <div style="text-align:center;">
                    <a href="<?= base_url('orderdetail/delete/' . $list['id_order']) ?>">
                      <button type="button" class="btn btn-danger btn-sm" name="hapus_vendor">
                        <i class="fas fa-trash-alt nav-icon"></i> Hapus
                      </button>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->