<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Tambah Data Store</h6>
    </div>
    <div class="card-body">
      <form action="<?= base_url('add_product') ?>" method="POST" class="form-horizontal form-label-right" enctype='multipart/form-data'>
        <div class="card-body">
          <div class="form-group row">
            <label for="alamat_store" class="col-sm-2 col-form-label">Kategori</label>
            <div class="col-sm-10">
              <select name="id_kategori" class="form-control">
                <option value="">--Pilih Kategori--</option>
                <?php foreach ($kategori as $list) : ?>
                  <option value="<?= $list['id_kategori'] ?>"><?= $list['nama_kategori'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-group row">
            <label for="no_tlp" class="col-sm-2 col-form-label">Vendor</label>
            <div class="col-sm-10">
              <select name="id_vendor" class="form-control">
                <option value="">--Pilih Vendor--</option>
                <?php foreach ($vendor as $list) : ?>
                  <option value="<?= $list['id_vendor'] ?>"><?= $list['nama_vendor'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-group row">
            <label for="no_tlp" class="col-sm-2 col-form-label">Store</label>
            <div class="col-sm-10">
              <select name="id_store" class="form-control">
                <option value="">--Pilih Store--</option>
                <?php foreach ($store as $list) : ?>
                  <option value="<?= $list['id_store'] ?>"><?= $list['alamat_store'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-group row">
            <label for="nama_produk" class="col-sm-2 col-form-label">Nama Produk</label>
            <div class="col-sm-10">
              <input type="text" name="nama_produk" class="form-control" id="nama_produk" placeholder="Nama Produk">
            </div>
          </div>

          <div class="form-group row">
            <label for="harga" class="col-sm-2 col-form-label">Harga</label>
            <div class="col-sm-10">
              <input type="text" name="harga" class="form-control" id="harga" placeholder="Harga">
            </div>
          </div>

          <div class="form-group row">
            <label for="nama_produk" class="col-sm-2 col-form-label">Stock</label>
            <div class="col-sm-10">
              <input type="text" name="stock" class="form-control" id="stock" placeholder="stock">
            </div>
          </div>

          <div class="form-group row">
            <label for="gambar" class="col-sm-2 col-form-label">Gambar</label>
            <div class="col-sm-10">
              <input type="file" name="gambar" class="form-control" id="gambar" placeholder="gambar">
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">Simpan</button>
          <a href="<?= base_url('product') ?>">
            <button type="button" class="btn btn-default swalDefaultSuccess">Kembali</button>
          </a>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /.container-fluid -->