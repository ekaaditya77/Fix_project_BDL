<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Store</h6>
    </div>
    <div class="card-body">

      <div class="form-group">
        <a href="<?= base_url('form_product') ?>">
          <button class="btn btn-sm btn-danger"><i class="fas fa-plus nav-icon"></i> Tambah Product</button>
        </a>
      </div>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Produk</th>
              <th>Kategori</th>
              <th>Vendor</th>
              <th>Harga Satuan</th>
              <th>Stock</th>
              <th>Cabang Toko</th>
              <th style="width: 300px;">Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($product as $list) : ?>
              <tr>
                <td><?= $list['nama_produk'] ?></td>
                <td><?= $list['nama_kategori'] ?></td>
                <td><?= $list['nama_vendor'] ?></td>
                <td><?= $list['harga'] ?></td>
                <td><?= $list['stock'] ?></td>
                <td><?= $list['alamat_store'] ?></td>
                <td>
                  <div style="text-align:center;">
                    <a href="<?= base_url('edit_product/') . $list['id_produk'] ?>" title="Preview">
                      <button type="button" class="btn btn-danger btn-sm">
                        <i class="fas fa-edit nav-icon"></i> Edit
                      </button>
                    </a>
                    <a href="<?= base_url('product/delete/' . $list['id_produk']) ?>">
                      <button type="button" class="btn btn-danger btn-sm" name="hapus_vendor">
                        <i class="fas fa-trash-alt nav-icon"></i> Hapus
                      </button>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->