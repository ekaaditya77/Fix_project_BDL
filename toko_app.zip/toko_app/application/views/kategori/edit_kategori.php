<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Edit Data Kategori</h6>
    </div>
    <div class="card-body">
      <form action="<?= base_url('edit_kategori/' . $kategori->id_kategori) ?>" method="POST" class="form-horizontal form-label-right">
        <div class="card-body">
          <div class="form-group row">
            <label for="nama_kategori" class="col-sm-2 col-form-label">Nama Kategori</label>
            <div class="col-sm-10">
              <input type="text" name="nama_kategori" class="form-control" id="nama_kategori" placeholder="Nama Kategori" value="<?= $kategori->nama_kategori ?>">
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">Simpan</button>
          <a href="<?= base_url('kategori') ?>">
            <button type="button" class="btn btn-default swalDefaultSuccess">Kembali</button>
          </a>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /.container-fluid -->