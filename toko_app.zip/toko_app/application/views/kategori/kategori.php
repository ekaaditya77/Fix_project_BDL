<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Kategori</h6>
    </div>
    <div class="card-body">

      <div class="form-group">
        <a href="<?= base_url('tambah_kategori') ?>">
          <button class="btn btn-sm btn-danger"><i class="fas fa-plus nav-icon"></i> Tambah Kategori</button>
        </a>
      </div>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Kategori</th>
              <th style="width: 300px;">Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($kategori as $list) : ?>
              <tr>
                <td><?= $list['nama_kategori'] ?></td>
                <td>
                  <div style="text-align:center;">
                    <a href="<?= base_url('edit_kategori/') . $list['id_kategori'] ?>" title="Preview">
                      <button type="button" class="btn btn-danger btn-sm">
                        <i class="fas fa-edit nav-icon"></i> Edit
                      </button>
                    </a>
                    <a href="<?= base_url('kategori/delete/' . $list['id_kategori']) ?>">
                      <button type="button" class="btn btn-danger btn-sm" name="hapus_kategori">
                        <i class="fas fa-trash-alt nav-icon"></i> Hapus
                      </button>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->