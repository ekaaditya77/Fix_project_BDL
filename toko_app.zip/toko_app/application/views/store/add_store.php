<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Tambah Data Store</h6>
    </div>
    <div class="card-body">
      <form action="<?= base_url('tambah_store') ?>" method="POST" class="form-horizontal form-label-right">
        <div class="card-body">
          <div class="form-group row">
            <label for="alamat_store" class="col-sm-2 col-form-label">Alamat Store</label>
            <div class="col-sm-10">
              <input type="text" name="alamat_store" class="form-control" id="alamat_store" placeholder="Alamat Store">
            </div>
          </div>

          <div class="form-group row">
            <label for="no_tlp" class="col-sm-2 col-form-label">No Telepon</label>
            <div class="col-sm-10">
              <input type="text" name="no_tlp" class="form-control" id="no_tlp" placeholder="No Telepon">
            </div>
          </div>

          <!-- <div class="form-group row">
            <label for="no_tlp" class="col-sm-2 col-form-label">No Telepon</label>
            <div class="col-sm-10">
              <input type="text" name="no_tlp" class="form-control" id="no_tlp" placeholder="No Telepon">
            </div>
          </div> -->
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">Simpan</button>
          <a href="<?= base_url('kategori') ?>">
            <button type="button" class="btn btn-default swalDefaultSuccess">Kembali</button>
          </a>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /.container-fluid -->