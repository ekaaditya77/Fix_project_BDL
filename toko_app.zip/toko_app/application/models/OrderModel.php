<?php
defined('BASEPATH') or exit('No direct script access allowed');

class OrderModel extends CI_Model
{
  public $table = 'order_detail';

  public function Get()
  {
    $this->db->select('*')
      ->from($this->table)
      ->join('customers', 'customers.id_customer = order_detail.id_customer')
      ->join('produk', 'produk.id_produk = order_detail.id_produk')
      ->join('kategori', 'kategori.id_kategori = produk.id_kategori');
    return $this->db->get();
  }

  public function GetById($id)
  {
    $this->db->select('*')
      ->from($this->table)
      ->join('produk', 'produk.id_produk = order_detail.id_produk')
      ->join('customers', 'customers.id_customer = order_detail.id_customer')
      ->where('order_detail.id_customer', $id)
      ->where('order_detail.status_order', 0);
    return $this->db->get();
  }

  public function GetRiwayat($id)
  {
    $this->db->select('*')
      ->from($this->table)
      ->join('produk', 'produk.id_produk = order_detail.id_produk')
      ->join('customers', 'customers.id_customer = order_detail.id_customer')
      ->join('kategori', 'kategori.id_kategori = produk.id_kategori')
      ->join('store', 'store.id_store = produk.id_store')
      ->where('order_detail.id_customer', $id);
    return $this->db->get();
  }

  public function insert($data)
  {
    $this->db->insert($this->table, $data);
    return $this->db->insert_id();
  }

  public function update($id, $data)
  {
    $this->db->where($id)
      ->update($this->table, $data);
    return $this->db->affected_rows() > 0;
  }

  public function delete($id)
  {
    $this->db->where($id)
      ->delete($this->table);
    return $this->db->affected_rows() > 0;
  }

  public function GetJmlCart($id)
  {
    $this->db->select('*')
      ->from($this->table)
      ->where('id_customer', $id)
      ->where('status_order', 0);
    return $this->db->get()->num_rows();
  }
}
