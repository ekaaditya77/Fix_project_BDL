<?php
defined('BASEPATH') or exit('No direct script access allowed');

class VendorModel extends CI_Model
{
  public $table = 'vendor';

  public function Get()
  {
    $this->db->select('*')
      ->from($this->table);
    return $this->db->get();
  }

  public function GetById($id)
  {
    $this->db->select('*')
      ->from($this->table)
      ->where($id);
    return $this->db->get();
  }

  public function insert($data)
  {
    $this->db->insert($this->table, $data);
    return $this->db->insert_id();
  }

  public function update($id, $data)
  {
    $this->db->where($id)
      ->update($this->table, $data);
    return $this->db->affected_rows() > 0;
  }

  public function delete($id)
  {
    $this->db->where($id)
      ->delete($this->table);
    return $this->db->affected_rows() > 0;
  }
}
