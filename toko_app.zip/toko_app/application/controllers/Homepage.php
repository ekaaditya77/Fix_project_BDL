<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Homepage extends CI_Controller
{
  public $page = 'store';

  public function __construct()
  {
    date_default_timezone_set('Asia/Singapore');
    parent::__construct();
    //$this->load->library('excel');
  }
  public function page($id = null)
  {
    if ($id == null) {
      $data = [
        'ket_kategori' => null,
        'kategori' => $this->KategoriModel->get()->result_array(),
        'produk' => $this->ProductModel->Get()->result_array(),
        'store' => $this->StoreModel->Get()->result_array(),
        'cart' => $this->OrderModel->GetById($this->session->userdata('id_customer'))->result_array()
      ];
    } else {
      $data = [
        'ket_kategori' => $this->KategoriModel->GetById(['id_kategori' => $id])->row(),
        'kategori' => $this->KategoriModel->get()->result_array(),
        'produk' => $this->ProductModel->GetById(['produk.id_kategori' => $id])->result_array(),
        'store' => $this->StoreModel->Get()->result_array(),
        'cart' => $this->OrderModel->GetById($this->session->userdata('id_customer'))->result_array()
      ];
    }

    $this->load->view('frontend/store', $data);
  }

  public function add_cart($id)
  {
    $produk = $this->ProductModel->GetByIdProduk($id)->row();
    $currentTime = date('Y-m-d h:i:s', time());

    $data = [
      'id_produk' => $produk->id_produk,
      'tgl_order' => $currentTime,
      'status_order' => 0,
      'id_customer' => $this->session->userdata('id_customer')
    ];

    $this->OrderModel->insert($data);
    redirect('homepage/page');
  }

  public function bayar()
  {
    $order = $this->OrderModel->GetById($this->session->userdata('id_customer'))->result_array();


    for ($i = 0; $i < count($order); $i++) {
      $data = [
        'status_order' => 1,
      ];
      $id = ['id_customer' => $this->session->userdata('id_customer')];
      $this->OrderModel->update($id, $data);
    }
    $this->session->set_flashdata('flash', 'success');
    redirect('homepage/page');
  }

  public function riwayat($id = null)
  {
    if ($id == null) {
      $data = [
        'ket_kategori' => null,
        'kategori' => $this->KategoriModel->get()->result_array(),
        'produk' => $this->ProductModel->Get()->result_array(),
        'store' => $this->StoreModel->Get()->result_array(),
        'cart' => $this->OrderModel->GetById($this->session->userdata('id_customer'))->result_array(),
        'riwayat' => $this->OrderModel->GetRiwayat($this->session->userdata('id_customer'))->result_array()
      ];
    } else {
      $data = [
        'ket_kategori' => $this->KategoriModel->GetById(['id_kategori' => $id])->row(),
        'kategori' => $this->KategoriModel->get()->result_array(),
        'produk' => $this->ProductModel->GetById($id)->result_array(),
        'store' => $this->StoreModel->Get()->result_array(),
        'cart' => $this->OrderModel->GetById($this->session->userdata('id_customer'))->result_array(),
        'riwayat' => $this->OrderModel->GetRiwayat($this->session->userdata('id_customer'))->result_array()
      ];
    }

    $this->load->view('frontend/riwayat', $data);
  }

  public function delete($id)
  {
    $this->OrderModel->delete(['id_order' => $id]);
    redirect('homepage/page');
  }
}
