<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Store extends CI_Controller
{
  public $page = 'store';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'store' => $this->StoreModel->Get()->result_array()
    ];

    $this->template->load('template', 'store/store', $data);
  }

  public function _validate()
  {
    $this->form_validation->set_rules('alamat_store', 'Alamat_Store', 'required|trim');
    $this->form_validation->set_rules('no_tlp', 'No_Tlp', 'required|trim');
    // $this->form_validation->set_rules('jam_buka', 'Jam_Buka', 'required|trim');
  }

  public function add()
  {
    $this->_validate();
    if ($this->form_validation->run() == false) {
      $data = [
        'page' => $this->page,
      ];
      $this->template->load('template', 'store/add_store', $data);
    } else {
      $data = $this->input->post(null, true);
      $this->StoreModel->insert($data);
      redirect('store');
    }
  }

  public function edit()
  {
    $this->_validate();
    $id = $this->uri->segment(2);
    if ($this->form_validation->run()  == false) {
      $data = [
        'page' => $this->page,
        'store' => $this->StoreModel->GetById(['id_store' => $id])->row()
      ];
      $this->template->load('template', 'store/edit_store', $data);
    } else {
      $data = $this->input->post(null, true);
      $id = ['id_store' => $id];
      $this->StoreModel->update($id, $data);
      redirect('store');
    }
  }

  public function delete($id)
  {
    $this->StoreModel->delete(['id_store' => $id]);
    redirect('vendor');
  }
}
