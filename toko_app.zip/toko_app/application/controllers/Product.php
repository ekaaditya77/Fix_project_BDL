<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends CI_Controller
{
  public $page = 'product';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'product' => $this->ProductModel->Get()->result_array()
    ];

    $this->template->load('template', 'product/product', $data);
  }

  public function _validate()
  {
    $this->form_validation->set_rules('nama_produk', 'Nama_Produk', 'required|trim');
  }

  public function form_add()
  {
    $data = [
      'page' => $this->page,
      'vendor' => $this->VendorModel->get()->result_array(),
      'kategori' => $this->KategoriModel->get()->result_array(),
      'store' => $this->StoreModel->get()->result_array()
    ];


    $this->template->load('template', 'product/add_product', $data);
  }

  public function add()
  {
    $gambar = $_FILES['gambar'];

    if ($gambar == null) {
    } else {
      $config['upload_path']  = './assets/gambar';
      $config['allowed_types']  = "jpg|png|gif|jpeg|jfif";
      $this->upload->initialize($config);
      $this->load->library('upload', $config);
      if (!$this->upload->do_upload('gambar')) {
        $error = array('error' => $this->upload->display_errors());
        print_r($error);
        die;
      } else {
        $upload = $this->upload->data('file_name');
      }
    }

    $data = [
      'id_kategori' => $this->input->post('id_kategori'),
      'id_vendor' => $this->input->post('id_vendor'),
      'id_store' => $this->input->post('id_store'),
      'nama_produk' => $this->input->post('nama_produk'),
      'harga' => $this->input->post('harga'),
      'stock' => $this->input->post('stock'),
      'image' => $upload
    ];
    $this->ProductModel->insert($data);
    redirect('product');
  }

  public function edit()
  {
    $this->_validate();
    $id = $this->uri->segment(2);
    if ($this->form_validation->run()  == false) {
      $data = [
        'page' => $this->page,
        'product' => $this->ProductModel->GetById(['id_produk' => $id])->row(),
        'vendor' => $this->VendorModel->get()->result_array(),
        'kategori' => $this->KategoriModel->get()->result_array(),
        'store' => $this->StoreModel->get()->result_array()
      ];

      $this->template->load('template', 'product/edit_product', $data);
    } else {
      $data = $this->input->post(null, true);
      $id = ['id_produk' => $id];
      $cek = $this->ProductModel->update($id, $data);
      redirect('product');
    }
  }

  public function delete($id)
  {
    $this->ProductModel->delete(['id_produk' => $id]);
    redirect('product');
  }
}
