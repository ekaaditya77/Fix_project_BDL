<?php
defined('BASEPATH') or exit('No direct script access allowed');

class OrderDetail extends CI_Controller
{
  public $page = 'kategori';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'order' => $this->OrderModel->Get()->result_array()
    ];

    $this->template->load('template', 'order_detail/order_detail', $data);
  }


  public function delete($id)
  {
    $this->OrderModel->delete(['id_order' => $id]);
    redirect('order_detail');
  }
}
