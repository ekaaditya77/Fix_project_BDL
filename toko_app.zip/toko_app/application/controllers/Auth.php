<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
	public function index()
	{
		$this->form_validation->set_rules('username', 'Username', 'required|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');

		if ($this->form_validation->run() == false) {
			$this->load->view('auth/login');
		} else {
			$dataUser = $this->AdminModel->GetByEmail(['username' => $this->input->post('username')]);

			$password = $this->input->post('password');

			if ($password == $dataUser->password) {
				$userdata = [
					'id_admin' => $dataUser->id_admin,
					'nama_admin' => $dataUser->nama_admin,
					'level_admin' => $dataUser->level_admin,
				];
				$this->session->set_userdata($userdata);

				redirect('kategori');
			} else {
				redirect('login_admin');
			}
		}
	}

	public function login_customer()
	{
		$this->form_validation->set_rules('email', 'Email', 'required|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');

		if ($this->form_validation->run() == false) {
			$this->load->view('frontend/login');
		} else {
			$dataUser = $this->CustomerModel->GetByEmail(['email' => $this->input->post('email')]);

			$password = $this->input->post('password');

			if ($password == $dataUser->password) {
				$userdata = [
					'id_customer' => $dataUser->id_customer,
					'nama_customer' => $dataUser->nama_customer,
				];

				$this->session->set_userdata($userdata);

				redirect('homepage/page');
			} else {
				redirect('login_customer');
			}
		}
	}

	public function _validate()
	{
		$this->form_validation->set_rules('nama_customer', 'nama_customer', 'required|trim');
	}

	public function registrasi()
	{
		$this->_validate();
		if ($this->form_validation->run() == false) {
			$this->load->view('frontend/registrasi');
		} else {
			$data = $this->input->post(null, true);
			$this->CustomerModel->insert($data);
			redirect('registrasi');
		}
	}

	public function logout_customer()
	{
		$this->session->sess_destroy();

		redirect('homepage/page');
	}

	public function logout_admin()
	{
		$this->session->sess_destroy();

		redirect('login_admin');
	}
}
