<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Vendor extends CI_Controller
{
  public $page = 'vendor';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'vendor' => $this->VendorModel->Get()->result_array()
    ];

    $this->template->load('template', 'vendor/vendor', $data);
  }

  public function _validate()
  {
    $this->form_validation->set_rules('nama_vendor', 'Nama_Vendor', 'required|trim');
    $this->form_validation->set_rules('alamat_vendor', 'Alamat_Vendor', 'required|trim');
    $this->form_validation->set_rules('no_tlp', 'No_Tlp', 'required|trim');
  }

  public function add()
  {
    $this->_validate();
    if ($this->form_validation->run() == false) {
      $data = [
        'page' => $this->page,
      ];
      $this->template->load('template', 'vendor/add_vendor', $data);
    } else {
      $data = $this->input->post(null, true);
      $this->VendorModel->insert($data);
      redirect('vendor');
    }
  }

  public function edit()
  {
    $this->_validate();
    $id = $this->uri->segment(2);
    if ($this->form_validation->run()  == false) {
      $data = [
        'page' => $this->page,
        'vendor' => $this->VendorModel->GetById(['id_vendor' => $id])->row()
      ];
      $this->template->load('template', 'vendor/edit_vendor', $data);
    } else {
      $data = $this->input->post(null, true);
      $id = ['id_vendor' => $id];
      $this->VendorModel->update($id, $data);
      redirect('vendor');
    }
  }

  public function delete($id)
  {
    $this->VendorModel->delete(['id_vendor' => $id]);
    redirect('vendor');
  }
}
