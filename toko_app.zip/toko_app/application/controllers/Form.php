<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Form extends CI_Controller
{
  public $page = 'Form';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'kategori' => $this->KategoriModel->Get()->result_array()
    ];

    $this->template->load('template', 'form/form', $data);
  }

  public function _validate()
  {
    $this->form_validation->set_rules('nama_kategori', 'Nama_kategori', 'required|trim');
  }

  public function add()
  {
    $this->_validate();
    if ($this->form_validation->run() == false) {
      $data = [
        'page' => $this->page,
      ];
      $this->template->load('template', 'form/add_form', $data);
    } else {
      $data = $this->input->post(null, true);
      $this->KategoriModel->insert($data);
      redirect('kategori');
    }
  }

  public function edit()
  {
    $this->_validate();
    $id = $this->uri->segment(2);
    if ($this->form_validation->run()  == false) {
      $data = [
        'page' => $this->page,
        'kategori' => $this->KategoriModel->GetById(['id_kategori' => $id])->row()
      ];
      $this->template->load('template', 'kategori/edit_kategori', $data);
    } else {
      $data = $this->input->post(null, true);
      $id = ['id_kategori' => $id];
      $this->KategoriModel->update($id, $data);
      redirect('kategori');
    }
  }

  public function delete($id)
  {
    $this->KategoriModel->delete(['id_kategori' => $id]);
    redirect('kategori');
  }
}
