<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
  public $page = 'kategori';

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data = [
      'page' => $this->page,
      'admin' => $this->AdminModel->Get()->result_array()
    ];

    $this->template->load('template', 'admin/admin', $data);
  }

  public function _validate()
  {
    $this->form_validation->set_rules('nama_admin', 'nama_admin', 'required|trim');
  }

  public function add()
  {
    $this->_validate();
    if ($this->form_validation->run() == false) {
      $data = [
        'page' => $this->page,
      ];
      $this->template->load('template', 'admin/add_admin', $data);
    } else {
      $data = $this->input->post(null, true);
      $this->AdminModel->insert($data);
      redirect('admin');
    }
  }

  public function edit()
  {
    $this->_validate();
    $id = $this->uri->segment(2);
    if ($this->form_validation->run()  == false) {
      $data = [
        'page' => $this->page,
        'admin' => $this->AdminModel->GetById(['id_admin' => $id])->row()
      ];
      $this->template->load('template', 'admin/edit_admin', $data);
    } else {
      $data = $this->input->post(null, true);
      $id = ['id_admin' => $id];
      $this->AdminModel->update($id, $data);
      redirect('admin');
    }
  }

  public function delete($id)
  {
    $this->AdminModel->delete(['id_admin' => $id]);
    redirect('admin');
  }
}
